let text_cache = null;
// 监听按键事件
document.addEventListener('keydown', async function(event) {
    // 检查是否按下 Ctrl+C
    if (event.ctrlKey && event.key === 'c') {
        // 等待一小段时间确保系统复制操作完成
        setTimeout(async () => {
            try {
                // 获取学科信息
                const subject = await detectSubject();
                
                // 读取剪贴板内容
                const clipboardItems = await navigator.clipboard.read();
                let htmlContent = '';
                
                for (const item of clipboardItems) {
                    if (item.types.includes('text/html')) {
                        const htmlBlob = await item.getType('text/html');
                        htmlContent = await htmlBlob.text();
                        break;
                    }
                }

                if (!htmlContent) {
                    console.log('No HTML content found in clipboard');
                    return;
                }

                // 处理HTML内容
                const processedContent = await processClipboardContent(htmlContent, subject);
                text_cache = processedContent
                
                // 写回剪贴板
                const blob = new Blob([processedContent], { type: 'text/html' });
                const data = [
                    new ClipboardItem({
                        'text/html': blob
                    })
                ];
                await navigator.clipboard.write(data);
                
                // 显示通知
                showNotification(`文本已处理并复制到剪贴板 (${subject}模式)`);
                
            } catch (error) {
                console.error('Clipboard operation failed:', error);
                showNotification('处理失败，请检查权限设置');
            }
        }, 100); // 100ms 延迟确保系统复制操作完成
    }
});

// 检测学科的函数
async function detectSubject() {
    try {
        // 在主文档中查找元素
        const sourceDiv = document.querySelector('.index__source-13iEt');
        if (sourceDiv) {
            const text = sourceDiv.textContent;
            if (text.includes('英语')) {
                return '英语';
            }
            return '语数';
        }
        
        // 如果在主文档中没找到，尝试在iframe中查找
        const iframe = document.getElementById('task-container');
        if (iframe && iframe.contentDocument) {
            const iframeSourceDiv = iframe.contentDocument.querySelector('.index__source-13iEt');
            if (iframeSourceDiv) {
                const text = iframeSourceDiv.textContent;
                if (text.includes('英语')) {
                    return '英语';
                }
                return '语数';
            }
        }
        
        // 如果都没找到，返回默认值
        return '语数';
    } catch (error) {
        console.error('Error detecting subject:', error);
        return '语数'; // 出错时默认返回语数
    }
}

// 处理剪贴板内容的主函数
async function processClipboardContent(html, subject) {
    // 转换为纯文本，保留tex标签
    const text = htmlToText(html);
    // 处理文本
    const processedText = processTextWithTex(text, subject);
    // 转回HTML
    return textToHTML(processedText);
}

// HTML转文本函数
function htmlToText(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    let text = '';

    doc.body.childNodes.forEach((node) => {
        if (node.tagName === 'P' || node.tagName === 'BR' || node.tagName === 'SPAN') {
            let paragraph = '';
            node.childNodes.forEach((child) => {
                if (child.nodeType === Node.ELEMENT_NODE && child.tagName === 'TEX') {
                    paragraph += `<tex>${child.innerHTML}</tex>`;
                } else if (child.nodeType === Node.TEXT_NODE) {
                    paragraph += child.textContent;
                }
            });
            text += paragraph + '\n';
        }
    });

    return text.trim();
}

// 处理带TEX标签的文本
function processTextWithTex(text, subject) {
    // 提取 <tex> 标签内容
    const texSegments = [];
    const texRegex = /<tex>[\s\S]*?<\/tex>/g;

    // 使用占位符替换 <tex> 内容
    let processedText = text.replace(texRegex, (match) => {
        texSegments.push(match);
        return `☃TEX☃PLACEHOLDER☃${texSegments.length - 1}☃`;
    });

    // 处理普通文本
    processedText = processText(processedText, subject);

    // 处理公式部分
    texSegments.forEach((match, index) => {
        texSegments[index] = tex_process(match);
    });

    // 替换回原始的tex内容
    texSegments.forEach((texSegment, index) => {
        processedText = processedText.replace(
            `☃TEX☃PLACEHOLDER☃${index}☃`,
            texSegment
        );
    });

    return processedText;
}

// 文本转回HTML
function textToHTML(text) {
    return text
        .split('\n')
        .filter((line) => line.trim() !== '')
        .map((line) => {
            if (line.startsWith('<tex>') && line.endsWith('</tex>')) {
                return line;
            }
            return `<p>${line}</p>`;
        })
        .join('');
}

// 处理普通文本的函数
function processText(text, subject) {
    text = preprocess(text);
    text = amend_Punctuation(text);
    text = formatting(text);
    text = classified_process(text, subject);
    text = html_text(text);
    text = post_process(text);
    return text;
}

// 显示通知的函数
function showNotification(message) {
    const notificationElement = document.createElement('div');
    notificationElement.textContent = message;
    notificationElement.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        z-index: 10000;
        font-family: system-ui;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    `;
    
    document.body.appendChild(notificationElement);
    
    // 3秒后移除通知
    setTimeout(() => {
        notificationElement.style.opacity = '0';
        notificationElement.style.transition = 'opacity 0.5s ease';
        setTimeout(() => {
            notificationElement.remove();
        }, 500);
    }, 3000);
}
// 创建一个图标按钮
const toggleButton = document.createElement('div');
toggleButton.textContent = '🔑';
toggleButton.style.position = 'fixed';
toggleButton.style.bottom = '20px';
toggleButton.style.left = '20px';
toggleButton.style.zIndex = 1000;
toggleButton.style.cursor = 'pointer';
toggleButton.style.fontSize = '24px';
toggleButton.style.backgroundColor = '#fff';
toggleButton.style.border = '1px solid #ccc';
toggleButton.style.borderRadius = '50%';
toggleButton.style.width = '40px';
toggleButton.style.height = '40px';
toggleButton.style.display = 'flex';
toggleButton.style.alignItems = 'center';
toggleButton.style.justifyContent = 'center';
toggleButton.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';

// 创建一个悬浮框
const floatingBox = document.createElement('div');
floatingBox.style.position = 'fixed';
floatingBox.style.bottom = '70px';
floatingBox.style.left = '20px';
floatingBox.style.zIndex = 1000;
floatingBox.style.backgroundColor = '#fff';
floatingBox.style.border = '1px solid #ccc';
floatingBox.style.padding = '20px';
floatingBox.style.borderRadius = '12px';
floatingBox.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
floatingBox.style.width = '600px';
floatingBox.style.maxHeight = '750px';
floatingBox.style.overflowY = 'auto';
floatingBox.style.display = 'none';
floatingBox.style.transition = 'opacity 0.3s, transform 0.3s';
floatingBox.style.opacity = '0';
floatingBox.style.transform = 'translateY(10px)';
floatingBox.style.textAlign = 'left';

// 创建一个按钮
const pasteButton = document.createElement('button');
pasteButton.textContent = 'Paste from Clipboard';
pasteButton.style.width = '100%';
pasteButton.style.padding = '10px';
pasteButton.style.marginBottom = '15px';
pasteButton.style.border = '1px solid #ddd';
pasteButton.style.borderRadius = '8px';
pasteButton.style.backgroundColor = '#f9f9f9';
pasteButton.style.cursor = 'pointer';

// 创建显示区域
const descriptionsArea = document.createElement('div');
descriptionsArea.style.padding = '15px';
descriptionsArea.style.backgroundColor = '#f9f9f9';
descriptionsArea.style.borderRadius = '8px';
descriptionsArea.style.fontSize = '14px';
descriptionsArea.style.color = '#333';
descriptionsArea.style.whiteSpace = 'pre-wrap';
descriptionsArea.style.marginBottom = '15px';
descriptionsArea.style.display = 'none';
descriptionsArea.style.fontWeight = 'bold';
descriptionsArea.textContent = 'Descriptions:';
descriptionsArea.style.textAlign = 'left';

const answerArea = document.createElement('div');
answerArea.style.padding = '15px';
answerArea.style.backgroundColor = '#f9f9f9';
answerArea.style.borderRadius = '8px';
answerArea.style.fontSize = '14px';
answerArea.style.color = '#333';
answerArea.style.whiteSpace = 'pre-wrap';
answerArea.style.display = 'none';
answerArea.style.fontWeight = 'bold';
answerArea.textContent = 'Answer:';
answerArea.style.textAlign = 'left'; 

// 将按钮和显示区域添加到悬浮框中
floatingBox.appendChild(pasteButton);
floatingBox.appendChild(descriptionsArea);
floatingBox.appendChild(answerArea);

// 将图标按钮和悬浮框添加到页面上
document.body.appendChild(toggleButton);
document.body.appendChild(floatingBox);

// 监听图标按钮的点击事件
toggleButton.addEventListener('click', () => {
  if (floatingBox.style.display === 'none') {
    floatingBox.style.display = 'block';
    setTimeout(() => {
      floatingBox.style.opacity = '1';
      floatingBox.style.transform = 'translateY(0)';
    }, 10);
  } else {
    floatingBox.style.opacity = '0';
    floatingBox.style.transform = 'translateY(10px)';
    setTimeout(() => {
      floatingBox.style.display = 'none';
    }, 300);
  }
});

// 监听按钮的点击事件
pasteButton.addEventListener('click', async () => {
  try {
    let text = text_cache;
    //text = htmlToText(text);
    chrome.storage.local.get(['userKey'], async (result) => {
        const apiKey = result.userKey || 'No key saved';
        const system_prompt = `
你是一名试题格式化专员，负责对经OCR识别和初步正则处理的试题文本进行人工审核前的格式规范和校对。
基本信息：
输入是html标签的文本，<p>标签表示换行。输出时请用'\n'表示换行。
输出格式为：
json
{
    "descriptions": "处理说明、疑虑或警告信息",
    "answer": "格式化后的试题内容"
}
请严格遵循以下规则：

1.试题内容规范：
-每次只处理一个题目
-仅限中小学数学、语文、英语、物理、化学科目
-保留题型说明（如"选择题"）
-删除无关信息（考试地点、分值等）
-删除题目末尾与题目语义不相关的零散文字或单词，这些通常是OCR误识别的手写答案
-<tex>标签内的文字是公式，一般不要修改
-"陈陶修　2400110104"这样与试题无关的唐突字符，是OCR识别的水印，可去掉

2.作答区域规范
-普通填空：4个下划线，如 A ____ a day
-简答题：8个下划线：________
-英文题目括号：(　)（中间用全角空格），如 A (　) a day
-中文题目括号：（）（无需空格），如 一天一个（）
-下划线括号都是填空作答区，格式错误可以修改，但二者之间不要替换，也不要把题自己做了

3.选项格式规范
-大部分题目标准格式：数字/字母+英文句点+半角空格（如"1. "或"A. "）
-选择题的题干中（不是选项中）必须包含作答区（括号或下划线），没有时在开头补充括号
-圆圈数字（①②③等）使用时不加句点，是否在其后添加半角空格需要依据输入文本的主流格式，但同一题目中的格式必须统一。
-（1）（A）型选项不需要句点和空格
-根据题目语言选择中文或英文括号
-统一同一题目内的选项格式

4.标点与空格规范
英文内容：
-使用英文标点
-按英文习惯使用空格
-英文句点.和下个句子要有空格，引号，括号和内部文字之间无空格，如(A apple a day)
-删除单词跨行处理时遗留的连字符或空格，如"ap-ple"或"ap ple"->"apple",合并后的单词如有疑问需标注❄
中文内容：
-使用中文标点
-根据语义修正引号方向
其他要求：
-根据语义删除或添加OCR误识别的换行
-根据上下文补全或修正括号
-成语题，诗词填写等可根据字数推测格式，修正误识别的答题区

5.排版规范
基本要求：
-不使用空行
-不使用半角空格占位,中文需要占位使用全角空格"　"
-数理化，中文中的数字单位等符号旁边也尽量不要加空格
-你可以给文字加点，下划线以及加粗，如"<u>画线</u>文字,<b>加粗</b>文字,<span style="text-emphasis: dot under;">加点</span>文字。"
-由于OCR识别不出这些格式，如果题目明确要求加点字等，你可以根据题意给概率较大的部分赋予格式
段落处理：
-需要缩进时使用两个全角空格："　　",较长的文本段首都需要缩进(重点)，如"　　My name is ..."
-避免在不需要的地方加空格（如句末、中文与数字之间等），中文题目需要占位请用全角"　"，如一行若干个补全词语题：“如痴如（）　艳阳（）照”
-避免连续换行造成的空行，即使是段落间或大题作答区也不要空行
-排序题每个题都要换行，补全对话每个任务要换行，不要删除他们的换行符

6.输出规范
-answer中的文字会进入程序处理，descriptions仅供人工参考。
-确定的修改直接在answer中更正
-不确定的修改在descriptions中说明
-用❄标注需要人工确认的修改，如aple修改为apple❄
-标点和占位符可以大胆修改，题目内容修改需谨慎并标注。除上述情况，对于题目文本（即非符号部分）的修改都需要标注❄，如错别字

7.不录入情况
-发现超纲或超范围内容需在descriptions说明并返回空answer，常见的超纲题目有、会计题、计算机题、工程制图等
-多个不相关题目时在descriptions说明一图多题情况
-无法确定是否录入，则录入并在descriptions中警告

8.其他情况:
-题目开头若有用户特殊需求说明（如"题目要加粗。"、"所有选项都要加点。"等），应优先遵循这些要求处理题目，但在输出时不保留这部分说明文字。
-整体规则仅供参考，需根据具体情况灵活处理
        `;
        const messages = [
            { role: "system", content: system_prompt },
            { role: "user", content: text }
        ];
        const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
              model: 'deepseek-chat',
              messages: messages,
              response_format: { type: 'json_object' }
          })
      });
        if (!response.ok) {
            throw new Error('API请求失败');
        }
        const data = await response.json();
        const content = data.choices[0].message.content.trim();
        const resultJson = JSON.parse(content);
        descriptionsArea.style.display = 'block';
        answerArea.style.display = 'block';
        descriptionsArea.textContent = `${resultJson.descriptions || 'N/A'}`;
        answerArea.textContent = `${resultJson.answer || 'N/A'}`;
        // 写回剪贴板
        let temp = textToHTML(resultJson.answer);
        const blob = new Blob([temp], { type: 'text/html' });
        const clipboardData = [new ClipboardItem({'text/html': blob})];
        await navigator.clipboard.write(clipboardData);
    });
} catch (error) {
    console.error('发生错误:', error);
    descriptionsArea.style.display = 'block';
    answerArea.style.display = 'block';
    descriptionsArea.textContent = 'Descriptions: ';
    answerArea.textContent = `Answer: 发生错误，请检查控制台日志。`;
}
});