document.getElementById('saveKey').addEventListener('click', () => {
  const key = document.getElementById('keyInput').value;
  chrome.storage.local.set({ userKey: key }, () => {
    console.log('Key saved:', key);
    window.close(); // 关闭弹出窗口
  });
});